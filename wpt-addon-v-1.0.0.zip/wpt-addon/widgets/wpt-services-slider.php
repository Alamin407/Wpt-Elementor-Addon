<?php
namespace Elementor;

class Wpt_Services_Slider extends Widget_Base {

    public function get_name() {
        return  'wpt-services-slider-id';
    }

    public function get_title() {
        return esc_html__( 'Wpt Services Slider', 'wpt-addon' );
    }

    public function get_script_depends() {
        return [
            'wpt-main-js'
        ];
    }

    public function get_icon() {
        return 'eicon-slider-3d';
    }

    public function get_categories() {
        return [ 'wpt-for-elementor' ];
    }

    public function register_controls() {
        $this->start_controls_section(
			'wpt_service_slider_content_section',
			[
				'label' => esc_html__( 'Content', 'wpt-addon' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
        );

        // Service Title
        $this->add_control(
			'wpt_service_slider_content_title',
			[
				'label' => esc_html__( 'Title', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Default title', 'wpt-addon' ),
				'placeholder' => esc_html__( 'Type your title here', 'wpt-addon' ),
                'label_block' => true,
			]
		);

        // Service Headline
        $this->add_control(
			'wpt_service_slider_content_headline',
			[
				'label' => esc_html__( 'Headline', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Default title', 'wpt-addon' ),
				'placeholder' => esc_html__( 'Type your title here', 'wpt-addon' ),
                'label_block' => true,
			]
		);

        $this->end_controls_section();
        $this->start_controls_section(
			'wpt_service_slider_list_section',
			[
				'label' => esc_html__( 'Services', 'wpt-addon' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
        );
        // Repeater
        $repeater = new \Elementor\Repeater();
        // Image
        $repeater->add_control(
			'wpt_service_slider_image',
			[
				'label' => esc_html__( 'Choose Image', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);
        //Title
        $repeater->add_control(
			'wpt_service_slider_list_title',
			[
				'label' => esc_html__( 'Title', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'List Title' , 'wpt-addon' ),
				'label_block' => true,
			]
		);
        // Description
        $repeater->add_control(
			'wpt_service_slider_list_content',
			[
				'label' => esc_html__( 'Content', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::WYSIWYG,
				'default' => esc_html__( 'List Content' , 'wpt-addon' ),
				'show_label' => false,
			]
		);
        
        // Loop
        $this->add_control(
			'wpt_service_slider_list',
			[
				'label' => esc_html__( 'Wpt Services List', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'wpt_service_slider_list_title' => esc_html__( 'Title #1', 'wpt-addon' ),
						'wpt_service_slider_list_content' => esc_html__( 'Item content. Click the edit button to change this text.', 'wpt-addon' ),
					],
					[
						'wpt_service_slider_list_title' => esc_html__( 'Title #2', 'wpt-addon' ),
						'wpt_service_slider_list_content' => esc_html__( 'Item content. Click the edit button to change this text.', 'wpt-addon' ),
					],
				],
				'title_field' => '{{{ wpt_service_slider_list_title }}}',
			]
		);
        
        $this->end_controls_section();

        $this->start_controls_section(
			'wpt_service_slider_settings_section',
			[
				'label' => esc_html__( 'Settings', 'wpt-addon' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
        );
        // show Loop
        $this->add_control(
            'wpt_service_slider_loop',
            [
                'label' => __( 'Loop', 'plugin-domain' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'Show', 'your-plugin' ),
                'label_off' => __( 'Hide', 'your-plugin' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        // show Dots
        $this->add_control(
            'wpt_service_slider_dots',
            [
                'label' => __( 'Dots', 'plugin-domain' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'Show', 'your-plugin' ),
                'label_off' => __( 'Hide', 'your-plugin' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        // Show Navs
        $this->add_control(
            'wpt_service_slider_navs',
            [
                'label' => __( 'Navs', 'plugin-domain' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'Show', 'your-plugin' ),
                'label_off' => __( 'Hide', 'your-plugin' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        // Margin
        $this->add_control(
			'wpt_service_slider_margin',
			[
				'label' => esc_html__( 'Margin', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'step' => 1,
				'default' => 10,
                'placeholder' => __( 'Enter the margin between to sliders', 'wpt-addon' ),
			]
		);

        $this->end_controls_section();

		$this->style_tab();
    }

	private function style_tab(){
        $this->start_controls_section(
			'wpt_service_slider_content_body_style_section',
			[
				'label' => esc_html__( 'Content Body Style', 'wpt-addon' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

        // Wrapper Style
        $this->add_control(
			'wpt_service_slider_wrapper_style',
			[
				'label' => esc_html__( 'Wrapper', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

        // Background
        $this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'wpt_service_slider_wrapper_background',
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .wpt-service-wrap',
			]
		);

        // Padding
        $this->add_responsive_control(
			'wpt_service_slider_wrapper_padding',
			[
				'label' => esc_html__( 'Padding', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .wpt-service-wrap' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

        // Box Shadow
        $this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'wpt_service_slider_wrapper_box_shadow',
				'selector' => '{{WRAPPER}} .wpt-service-wrap',
			]
		);

        //Content Body Padding
        $this->add_control(
			'wpt_service_slider_cotent_body',
			[
				'label' => esc_html__( 'Content Body Padding', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

        $this->add_responsive_control(
			'wpt_service_slider_cotent_body_padding',
			[
				'label' => esc_html__( 'Padding', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .wpt-service-wrap .wpt-services-left' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

        // Slider Body Style
        $this->add_control(
			'wpt_service_slider_body',
			[
				'label' => esc_html__( 'Services Body Padding', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

        $this->add_responsive_control(
			'wpt_service_slider_body_padding',
			[
				'label' => esc_html__( 'Padding', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .wpt-service-wrap .wpt-service-carousel' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

        $this->end_controls_section();

        $this->start_controls_section(
			'wpt_service_slider_content_style_section',
			[
				'label' => esc_html__( 'Content Style', 'wpt-addon' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

        // Content Title Style
        $this->add_control(
			'wpt_service_content_title_style',
			[
				'label' => esc_html__( 'Title', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

        // Typhography
        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'wpt_service_content_title_typography',
				'selector' => '{{WRAPPER}} .wpt-service-wrap .wpt-services-left .wpt-lft-title',
			]
		);

        // Color
        $this->add_control(
			'wpt_service_content_title_color',
			[
				'label' => esc_html__( 'Title Color', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .wpt-service-wrap .wpt-services-left .wpt-lft-title' => 'color: {{VALUE}}',
				],
			]
		);

        // Margin
        $this->add_responsive_control(
			'wpt_service_content_title_margin',
			[
				'label' => esc_html__( 'Margin', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 10,
				],
				'selectors' => [
					'{{WRAPPER}} .wpt-service-wrap .wpt-services-left .wpt-lft-title' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

        // Content Headline Style
        $this->add_control(
			'wpt_service_content_headline_style',
			[
				'label' => esc_html__( 'Headline', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

        // Typhography
        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'wpt_service_content_heading_typography',
				'selector' => '{{WRAPPER}} .wpt-service-wrap .wpt-services-left .wpt-serv-name',
			]
		);

        // Color
        $this->add_control(
			'wpt_service_content_heading_color',
			[
				'label' => esc_html__( 'Heading Color', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .wpt-service-wrap .wpt-services-left .wpt-serv-name' => 'color: {{VALUE}}',
				],
			]
		);

        // Margin
        $this->add_responsive_control(
			'wpt_service_content_Heading_margin',
			[
				'label' => esc_html__( 'Margin', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 10,
				],
				'selectors' => [
					'{{WRAPPER}} .wpt-service-wrap .wpt-services-left .wpt-serv-name' => 'margin-top: {{SIZE}}{{UNIT}};',
				],
			]
		);

        $this->end_controls_section();

        $this->start_controls_section(
			'wpt_service_slider_style_section',
			[
				'label' => esc_html__( 'Services Style', 'wpt-addon' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

        // Slider Item Body
        $this->add_control(
			'wpt_service_slider_item_style',
			[
				'label' => esc_html__( 'Item Body', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

        // Background
        $this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'wpt_service_slider_item_background',
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .wpt-service-wrap .wpt-service-carousel .item',
			]
		);

        // Padding
        $this->add_responsive_control(
			'wpt_service_slider_item_padding',
			[
				'label' => esc_html__( 'Padding', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .wpt-service-wrap .wpt-service-carousel .item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

        // Box Shadow
        $this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'wpt_service_slider_item_box_shadow',
				'selector' => '{{WRAPPER}} .wpt-service-wrap .wpt-service-carousel .item',
			]
		);

        // Services Item Image
        $this->add_control(
			'wpt_service_item_image_style',
			[
				'label' => esc_html__( 'Image', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

        // Background
        $this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'wpt_service_item_image_background',
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .wpt-service-wrap .wpt-service-carousel .item .wpt-ser-content .wpt-ser-icon .wpt-ser-icon-img',
			]
		);

        // Width
        $this->add_responsive_control(
			'wpt_service_item_image_width',
			[
				'label' => esc_html__( 'Width', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 80,
				],
				'selectors' => [
					'{{WRAPPER}} .wpt-service-wrap .wpt-service-carousel .item .wpt-ser-content .wpt-ser-icon .wpt-ser-icon-img' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

        // Height
        $this->add_responsive_control(
			'wpt_service_item_image_height',
			[
				'label' => esc_html__( 'Height', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 80,
				],
				'selectors' => [
					'{{WRAPPER}} .wpt-service-wrap .wpt-service-carousel .item .wpt-ser-content .wpt-ser-icon .wpt-ser-icon-img' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

        // Border Radius
        $this->add_control(
			'wpt_service_item_image_border_radius',
			[
				'label' => esc_html__( 'Border Radius', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .wpt-service-wrap .wpt-service-carousel .item .wpt-ser-content .wpt-ser-icon .wpt-ser-icon-img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
                'default' => [
                    'top'   => '50',
                    'right' => '50',
                    'bottom'  => '50',
                    'left'  => '50',
                ],
			]
		);

        // Padding
        $this->add_responsive_control(
			'wpt_service_item_image_padding',
			[
				'label' => esc_html__( 'Padding', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .wpt-service-wrap .wpt-service-carousel .item .wpt-ser-content .wpt-ser-icon .wpt-ser-icon-img' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

        // Margin
        $this->add_responsive_control(
			'wpt_service_item_image_margin',
			[
				'label' => esc_html__( 'Margin', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 10,
				],
				'selectors' => [
					'{{WRAPPER}} .wpt-service-wrap .wpt-service-carousel .item .wpt-ser-content .wpt-ser-icon' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

        // Services Item Title
        $this->add_control(
			'wpt_service_item_title_style',
			[
				'label' => esc_html__( 'Title Style', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

        // Color
        $this->add_control(
			'wpt_service_item_title_color',
			[
				'label' => esc_html__( 'Title Color', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .wpt-service-wrap .wpt-service-carousel .item .wpt-ser-content .wpt-ser-title h3' => 'color: {{VALUE}}',
				],
			]
		);

        // Typhography
        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'wpt_service_item_title_typography',
				'selector' => '{{WRAPPER}} .wpt-service-wrap .wpt-service-carousel .item .wpt-ser-content .wpt-ser-title h3',
			]
		);

        // Margin
        $this->add_responsive_control(
			'wpt_service_item_title_margin',
			[
				'label' => esc_html__( 'Margin', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 10,
				],
				'selectors' => [
					'{{WRAPPER}} .wpt-service-wrap .wpt-service-carousel .item .wpt-ser-content .wpt-ser-title h3' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

        // Services Item Description
        $this->add_control(
			'wpt_service_item_desc_style',
			[
				'label' => esc_html__( 'Description Style', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

        // Color
        $this->add_control(
			'wpt_service_item_desc_color',
			[
				'label' => esc_html__( 'Title Color', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .wpt-service-wrap .wpt-service-carousel .item .wpt-ser-content .wpt-ser-des p' => 'color: {{VALUE}}',
				],
			]
		);

        // Typhography
        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'wpt_service_item_desc_typography',
				'selector' => '{{WRAPPER}} .wpt-service-wrap .wpt-service-carousel .item .wpt-ser-content .wpt-ser-des p',
			]
		);

        $this->end_controls_section();

        $this->start_controls_section(
			'wpt_service_slider_nav_style_section',
			[
				'label' => esc_html__( 'Navigation Style', 'wpt-addon' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

        //Previous Icon
        $this->add_control(
			'wpt_service_slider_nav_prev_style',
			[
				'label' => esc_html__( 'Previous Icon', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->start_controls_tabs(
			'wpt_service_slider_nav_prev_style_tabs'
		);

        $this->start_controls_tab(
			'wpt_service_slider_nav_prev_style_normal_tab',
			[
				'label' => esc_html__( 'Normal', 'wpt-addon' ),
			]
		);

        // Icon Color
        $this->add_control(
			'wpt_service_slider_nav_prev_icon_color',
			[
				'label' => esc_html__( 'Icon Color', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .wpt-service-carousel .owl-nav button.owl-prev i' => 'color: {{VALUE}}',
				],
			]
		);

        // Icon Background
        $this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'wpt_service_slider_nav_prev_icon_background',
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .wpt-service-carousel .owl-nav button.owl-prev',
			]
		);

        $this->end_controls_tab();

        // Hover Tab
        $this->start_controls_tab(
			'wpt_service_slider_nav_style_hover_tab',
			[
				'label' => esc_html__( 'Hover', 'wpt-addon' ),
			]
		);

        // Icon Color
        $this->add_control(
			'wpt_service_slider_nav_prev_icon_hov_color',
			[
				'label' => esc_html__( 'Icon Color', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .wpt-service-carousel .owl-nav button.owl-prev:hover i' => 'color: {{VALUE}}',
				],
			]
		);

        // Icon Background
        $this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'wpt_service_slider_nav_prev_icon_hov_background',
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .wpt-service-carousel .owl-nav button.owl-prev:hover',
			]
		);

        $this->end_controls_tab();
        $this->end_controls_tabs();

        //Next Icon
        $this->add_control(
			'wpt_service_slider_nav_next_style',
			[
				'label' => esc_html__( 'Next Icon', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->start_controls_tabs(
			'wpt_service_slider_nav_next_style_tabs'
		);

        $this->start_controls_tab(
			'wpt_service_slider_nav_next_style_normal_tab',
			[
				'label' => esc_html__( 'Normal', 'wpt-addon' ),
			]
		);

        // Icon Color
        $this->add_control(
			'wpt_service_slider_nav_next_icon_color',
			[
				'label' => esc_html__( 'Icon Color', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .wpt-service-carousel .owl-nav button.owl-next i' => 'color: {{VALUE}}',
				],
			]
		);

        // Icon Background
        $this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'wpt_service_slider_nav_next_icon_background',
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .wpt-service-carousel .owl-nav button.owl-next',
			]
		);

        $this->end_controls_tab();

        $this->start_controls_tab(
			'wpt_service_slider_nav_next_style_hover_tab',
			[
				'label' => esc_html__( 'Hover', 'wpt-addon' ),
			]
		);

        // Icon Color
        $this->add_control(
			'wpt_service_slider_nav_next_icon_hov_color',
			[
				'label' => esc_html__( 'Icon Color', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .wpt-service-carousel .owl-nav button.owl-next:hover i' => 'color: {{VALUE}}',
				],
			]
		);

        // Icon Background
        $this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'wpt_service_slider_nav_next_icon_hov_background',
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .wpt-service-carousel .owl-nav button.owl-next:hover',
			]
		);

        $this->end_controls_tab();
        $this->end_controls_tabs();

        // Icon Size
        $this->add_control(
			'wpt_service_slider_nav_icon_size_sty',
			[
				'label' => esc_html__( 'Icon Size', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

        // Font Size
        $this->add_responsive_control(
			'wpt_service_slider_nav_icon_size',
			[
				'label' => esc_html__( 'Size', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 20,
				],
				'selectors' => [
					'{{WRAPPER}} .wpt-service-carousel .owl-nav button i' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);

        // Icon Width
        $this->add_control(
			'wpt_service_slider_nav_icon_width_sty',
			[
				'label' => esc_html__( 'Icon Width', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

        // Width
        $this->add_responsive_control(
			'wpt_service_slider_nav_icon_width',
			[
				'label' => esc_html__( 'Width', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 50,
				],
				'selectors' => [
					'{{WRAPPER}} .wpt-service-carousel .owl-nav button' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

        // Icon Height
        $this->add_control(
			'wpt_service_slider_nav_icon_height_sty',
			[
				'label' => esc_html__( 'Icon Height', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

        // Width
        $this->add_responsive_control(
			'wpt_service_slider_nav_icon_height',
			[
				'label' => esc_html__( 'Height', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 50,
				],
				'selectors' => [
					'{{WRAPPER}} .wpt-service-carousel .owl-nav button' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

        // Border Radius
        $this->add_control(
			'wpt_service_slider_nav_icon_border-radius',
			[
				'label' => esc_html__( 'Border Radius', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .wpt-service-carousel .owl-nav button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
                'default' => [
                    'unit' => '%',
                    'top' => '50',
                    'right' => '50',
                    'bottom' => '50',
                    'left' => '50',
                ]
			]
		);

        // Space Between
        $this->add_control(
			'wpt_service_slider_nav_icon_space',
			[
				'label' => esc_html__( 'Space Between', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

        // Space
        $this->add_responsive_control(
			'wpt_service_slider_nav_icon_between',
			[
				'label' => esc_html__( 'Margin', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 15,
				],
				'selectors' => [
					'{{WRAPPER}} .wpt-service-carousel .owl-nav button.owl-prev' => 'margin-right: {{SIZE}}{{UNIT}};',
				],
			]
		);

		// Horizontal Align
		$this->add_responsive_control(
			'wpt_service_slider_nav_icon_left',
			[
				'label' => esc_html__( 'Horizontal Align', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => -302,
				],
				'selectors' => [
					'{{WRAPPER}} .wpt-service-carousel .owl-nav' => 'left: {{SIZE}}{{UNIT}};',
				],
			]
		);

		// Vertical Align
		$this->add_responsive_control(
			'wpt_service_slider_nav_icon_bottom',
			[
				'label' => esc_html__( 'Vertical Align', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 35,
				],
				'selectors' => [
					'{{WRAPPER}} .wpt-service-carousel .owl-nav' => 'bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);
        
        $this->end_controls_section();
	}

    protected function render() {
        $settings = $this->get_settings_for_display();
        $this->add_render_attribute(
            'service_carousel_options',
            [
                'id'          => 'service-carousel-' . $this->get_id(),
                'data-loop'   => $settings[ 'wpt_service_slider_loop' ],
                'data-dots'   => $settings[ 'wpt_service_slider_dots' ],
                'data-navs'   => $settings[ 'wpt_service_slider_navs' ],
                'data-margin' => $settings[ 'wpt_service_slider_margin' ],
            ]
        );
        ?>
            <div class="wpt-service-wrap">
                <div class="wpt-services-left">
                    <div class="wpt-services-left-content">
                        <h3 class="wpt-lft-title">
                            <?php echo $settings[ 'wpt_service_slider_content_title' ]; ?>
                        </h3>
                        <h2 class="wpt-serv-name">
                            <?php echo $settings[ 'wpt_service_slider_content_headline' ]; ?>
                        </h2>
                    </div>
                </div>
                <div class="owl-carousel owl-theme wpt-service-carousel" <?php echo $this->get_render_attribute_string( 'service_carousel_options' ); ?>>
                    <?php
                        if( $settings[ 'wpt_service_slider_list' ] ){
                            foreach( $settings[ 'wpt_service_slider_list' ] as $wptseritem ){
                                ?>
                                    <div class="item">
                                        <div class="wpt-ser-content">
                                            <div class="wpt-ser-icon">
                                                <div class="wpt-ser-icon-img">
                                                    <img src="<?php echo esc_url( $wptseritem[ 'wpt_service_slider_image' ][ 'url' ] ); ?>" alt="">
                                                </div>
                                            </div>
                                            <div class="wpt-ser-title">
                                                <h3><?php echo $wptseritem[ 'wpt_service_slider_list_title' ]; ?></h3>
                                            </div>
                                            <div class="wpt-ser-des">
                                                <p><?php echo $wptseritem[ 'wpt_service_slider_list_content' ]; ?></p>
                                            </div>
                                        </div>
                                    </div>
                                <?php
                            }
                        }
                    ?>
                </div>
            </div>
        <?php
    }

    protected function _content_template() {
		?>
            <#
                view.addRenderAttribute(
                    'service_carousel_options',
                    {
                        'id': 'service-carousel-id',
                        'data-loop': settings.wpt_service_slider_loop,
                        'data-dots': settings.wpt_service_slider_dots,
                        'data-navs': settings.wpt_service_slider_navs,
                        'data-margin': settings.wpt_service_slider_margin
                    }
                );
            #>
            <div class="wpt-service-wrap">
                <div class="wpt-services-left">
                    <div class="wpt-services-left-content">
                        <h3 class="wpt-lft-title">
                            {{{ settings.wpt_service_slider_content_title }}}
                        </h3>
                        <h2 class="wpt-serv-name">
                            {{{ settings.wpt_service_slider_content_headline }}}
                        </h2>
                    </div>
                </div>
                <div class="owl-carousel owl-theme wpt-service-carousel" {{{ view.getRenderAttributeString( 'service_carousel_options' ) }}} >
                    <# if ( settings.wpt_service_slider_list.length ) { #>
                        <# _.each( settings.wpt_service_slider_list, function( wptslideritem ) { #>
                            <div class="item">
                                <div class="wpt-ser-content">
                                    <div class="wpt-ser-icon">
                                        <div class="wpt-ser-icon-img">
                                            <img src="{{ wptslideritem.wpt_service_slider_image.url }}" alt="">
                                        </div>
                                    </div>
                                    <div class="wpt-ser-title">
                                        <h3>{{{ wptslideritem.wpt_service_slider_list_title }}}</h3>
                                    </div>
                                    <div class="wpt-ser-des">
                                        <p>{{{ wptslideritem.wpt_service_slider_list_content }}}</p>
                                    </div>
                                </div>
                            </div>
                        <# }); #>
                    <# } #>
                </div>
            </div>
        <?php
    }

}
Plugin::instance()->widgets_manager->register_widget_type( new Wpt_Services_Slider() );