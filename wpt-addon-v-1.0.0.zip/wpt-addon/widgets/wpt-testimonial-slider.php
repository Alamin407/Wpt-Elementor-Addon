<?php
namespace Elementor;

class Wpt_Testimonial_Slider extends Widget_Base {

    public function get_name() {
        return  'wpt-testimonial-slider-id';
    }

    public function get_title() {
        return esc_html__( 'Wpt Testimonial Slider', 'wpt-addon' );
    }

    public function get_script_depends() {
        return [
            'wpt-main-js'
        ];
    }

    public function get_icon() {
        return 'eicon-slider-album';
    }

    public function get_categories() {
        return [ 'wpt-for-elementor' ];
    }

    public function register_controls() {
        $this->start_controls_section(
			'wpt_tsm_slider_content_section',
			[
				'label' => esc_html__( 'Content', 'wpt-addon' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
        );

        // Repeater
        $repeater = new \Elementor\Repeater();
        // Image
        $repeater->add_control(
			'wpt_tsm_slider_image',
			[
				'label' => esc_html__( 'Choose Image', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);
        //Client Name
        $repeater->add_control(
			'wpt_tsm_slider_list_client',
			[
				'label' => esc_html__( 'Client Name', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Jhon Doe' , 'wpt-addon' ),
				'label_block' => true,
			]
		);

        //Client Name
        $repeater->add_control(
			'wpt_tsm_slider_list_title',
			[
				'label' => esc_html__( 'Client Title', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Manager' , 'wpt-addon' ),
				'label_block' => true,
			]
		);

        // Description
        $repeater->add_control(
			'wpt_tsm_slider_list_content',
			[
				'label' => esc_html__( 'Content', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::WYSIWYG,
				'default' => esc_html__( 'List Content' , 'wpt-addon' ),
				'show_label' => false,
			]
		);
        
        // Loop
        $this->add_control(
			'wpt_tsm_slider_list',
			[
				'label' => esc_html__( 'Wpt Testimonial List', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'wpt_tsm_slider_list_client' => esc_html__( 'Title #1', 'wpt-addon' ),
						'wpt_tsm_slider_list_content' => esc_html__( 'Item content. Click the edit button to change this text.', 'wpt-addon' ),
					],
					[
						'wpt_tsm_slider_list_client' => esc_html__( 'Title #2', 'wpt-addon' ),
						'wpt_tsm_slider_list_content' => esc_html__( 'Item content. Click the edit button to change this text.', 'wpt-addon' ),
					],
				],
				'title_field' => '{{{ wpt_tsm_slider_list_client }}}',
			]
		);

        $this->end_controls_section();

        $this->start_controls_section(
			'wpt_tsm_slider_settings_section',
			[
				'label' => esc_html__( 'Settings', 'wpt-addon' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
        );
        // show Loop
        $this->add_control(
            'wpt_tsm_slider_loop',
            [
                'label' => __( 'Loop', 'plugin-domain' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'Show', 'your-plugin' ),
                'label_off' => __( 'Hide', 'your-plugin' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );
        // Autoplay
        $this->add_control(
            'wpt_tsm_slider_autoplay',
            [
                'label' => __( 'Autoplay', 'plugin-domain' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'On', 'your-plugin' ),
                'label_off' => __( 'Off', 'your-plugin' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );
        // Autoplay Hover pause
        $this->add_control(
            'wpt_tsm_slider_pause',
            [
                'label' => __( 'Autoplay Hover Pause', 'plugin-domain' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'True', 'your-plugin' ),
                'label_off' => __( 'False', 'your-plugin' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        // show Dots
        $this->add_control(
            'wpt_tsm_slider_dots',
            [
                'label' => __( 'Dots', 'plugin-domain' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'Show', 'your-plugin' ),
                'label_off' => __( 'Hide', 'your-plugin' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        // Show Navs
        $this->add_control(
            'wpt_tsm_slider_navs',
            [
                'label' => __( 'Navs', 'plugin-domain' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'Show', 'your-plugin' ),
                'label_off' => __( 'Hide', 'your-plugin' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        // Margin
        $this->add_control(
			'wpt_tsm_slider_margin',
			[
				'label' => esc_html__( 'Margin', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'step' => 1,
				'default' => 10,
                'placeholder' => __( 'Enter the margin between to sliders', 'wpt-addon' ),
			]
		);

        $this->end_controls_section();

		$this->style_tab();
    }

	private function style_tab(){
        $this->start_controls_section(
			'wpt_tsm_slider_content_body_section',
			[
				'label' => esc_html__( 'Content Wrapper Style', 'wpt-addon' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

        // Wrapper Style
        $this->add_control(
			'wpt_tsm_slider_wrapper_style',
			[
				'label' => esc_html__( 'Wrapper', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

        // Padding
        $this->add_responsive_control(
			'wpt_tsm_slider_wrapper_padding',
			[
				'label' => esc_html__( 'Padding', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .wpt-testimonial-wrap' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

        // Padding
        $this->add_responsive_control(
			'wpt_tsm_slider_wrapper_radius',
			[
				'label' => esc_html__( 'Padding', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .wpt-testimonial-wrap' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

        // Content Wrapper Style
        $this->add_control(
			'wpt_tsm_slider_content_wrapper_style',
			[
				'label' => esc_html__( 'Content Wrapper', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

        // Background
        $this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'wpt_tsm_slider_content_wrapper_background',
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .wpt-testimonial-wrap .wpt-tsm-carousel .item .wpt-tsm-wrap .wpt-tsm-content',
			]
		);

        // Padding
        $this->add_responsive_control(
			'wpt_tsm_slider_content_wrapper_padding',
			[
				'label' => esc_html__( 'Padding', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .wpt-testimonial-wrap .wpt-tsm-carousel .item .wpt-tsm-wrap .wpt-tsm-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

        $this->end_controls_section();

        $this->start_controls_section(
			'wpt_tsm_slider_item_section',
			[
				'label' => esc_html__( 'Testimonials Style', 'wpt-addon' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

        // Image Style
        $this->add_control(
			'wpt_tsm_slider_item_image_style',
			[
				'label' => esc_html__( 'Image', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

        // Image Height
        // Margin
        $this->add_responsive_control(
			'wpt_tsm_slider_item_image_height',
			[
				'label' => esc_html__( 'Height', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 400,
				],
				'selectors' => [
					'{{WRAPPER}} .wpt-testimonial-wrap .wpt-tsm-carousel .item .wpt-tsm-wrap .wpt-tsm-avater' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

        // Border Radius
        $this->add_responsive_control(
			'wpt_tsm_slider_item_image_radius',
			[
				'label' => esc_html__( 'Border Radius', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .wpt-testimonial-wrap .wpt-tsm-carousel .item .wpt-tsm-wrap .wpt-tsm-avater' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

        // Description Style
        $this->add_control(
			'wpt_tsm_slider_item_desc',
			[
				'label' => esc_html__( 'Description', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

        // Color
        $this->add_control(
			'wpt_tsm_slider_item_desc_color',
			[
				'label' => esc_html__( 'Description Color', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .wpt-testimonial-wrap .wpt-tsm-carousel .item .wpt-tsm-wrap .wpt-tsm-content p' => 'color: {{VALUE}}',
				],
			]
		);

        // Typhography
        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'wpt_tsm_slider_item_desc_typography',
				'selector' => '{{WRAPPER}} .wpt-testimonial-wrap .wpt-tsm-carousel .item .wpt-tsm-wrap .wpt-tsm-content p',
			]
		);

        // Margin
        $this->add_responsive_control(
			'wpt_tsm_slider_item_desc_margin',
			[
				'label' => esc_html__( 'Margin', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 10,
				],
				'selectors' => [
					'{{WRAPPER}} .wpt-testimonial-wrap .wpt-tsm-carousel .item .wpt-tsm-wrap .wpt-tsm-content p' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

        // Client Style
        $this->add_control(
			'wpt_tsm_slider_item_client',
			[
				'label' => esc_html__( 'Client', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

        // Color
        $this->add_control(
			'wpt_tsm_slider_item_client_color',
			[
				'label' => esc_html__( 'Client Color', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .wpt-testimonial-wrap .wpt-tsm-carousel .item .wpt-tsm-wrap .wpt-tsm-content .wpt-tsm-client' => 'color: {{VALUE}}',
				],
			]
		);

        // Typhography
        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'wpt_tsm_slider_item_client_typography',
				'selector' => '{{WRAPPER}} .wpt-testimonial-wrap .wpt-tsm-carousel .item .wpt-tsm-wrap .wpt-tsm-content .wpt-tsm-client',
			]
		);

        // Margin
        $this->add_responsive_control(
			'wpt_tsm_slider_item_client_margin',
			[
				'label' => esc_html__( 'Margin', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 10,
				],
				'selectors' => [
					'{{WRAPPER}} .wpt-testimonial-wrap .wpt-tsm-carousel .item .wpt-tsm-wrap .wpt-tsm-content .wpt-tsm-client' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

        // Title Style
        $this->add_control(
			'wpt_tsm_slider_item_title',
			[
				'label' => esc_html__( 'Title', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

        // Color
        $this->add_control(
			'wpt_tsm_slider_item_title_color',
			[
				'label' => esc_html__( 'Title Color', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .wpt-testimonial-wrap .wpt-tsm-carousel .item .wpt-tsm-wrap .wpt-tsm-content .wpt-tsm-title' => 'color: {{VALUE}}',
				],
			]
		);

        // Typhography
        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'wpt_tsm_slider_item_title_typography',
				'selector' => '{{WRAPPER}} .wpt-testimonial-wrap .wpt-tsm-carousel .item .wpt-tsm-wrap .wpt-tsm-content .wpt-tsm-title',
			]
		);

        $this->end_controls_section();

        $this->start_controls_section(
			'wpt_tsm_slider_nav_style_section',
			[
				'label' => esc_html__( 'Navigation Style', 'wpt-addon' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

        //Previous Icon
        $this->add_control(
			'wpt_tsm_slider_nav_prev_style',
			[
				'label' => esc_html__( 'Previous Icon', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->start_controls_tabs(
			'wpt_tsm_slider_nav_prev_style_tabs'
		);

        $this->start_controls_tab(
			'wpt_tsm_slider_nav_prev_style_normal_tab',
			[
				'label' => esc_html__( 'Normal', 'wpt-addon' ),
			]
		);

        // Icon Color
        $this->add_control(
			'wpt_tsm_slider_nav_prev_icon_color',
			[
				'label' => esc_html__( 'Icon Color', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .wpt-tsm-carousel .owl-nav button.owl-prev i' => 'color: {{VALUE}}',
				],
			]
		);

        // Icon Background
        $this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'wpt_tsm_slider_nav_prev_icon_background',
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .wpt-tsm-carousel .owl-nav button.owl-prev',
			]
		);

        $this->end_controls_tab();

        // Hover Tab
        $this->start_controls_tab(
			'wpt_tsm_slider_nav_style_hover_tab',
			[
				'label' => esc_html__( 'Hover', 'wpt-addon' ),
			]
		);

        // Icon Color
        $this->add_control(
			'wpt_tsm_slider_nav_prev_icon_hov_color',
			[
				'label' => esc_html__( 'Icon Color', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .wpt-tsm-carousel .owl-nav button.owl-prev:hover i' => 'color: {{VALUE}}',
				],
			]
		);

        // Icon Background
        $this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'wpt_tsm_slider_nav_prev_icon_hov_background',
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .wpt-tsm-carousel .owl-nav button.owl-prev:hover',
			]
		);

        $this->end_controls_tab();
        $this->end_controls_tabs();

        //Next Icon
        $this->add_control(
			'wpt_tsm_slider_nav_next_style',
			[
				'label' => esc_html__( 'Next Icon', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->start_controls_tabs(
			'wpt_tsm_slider_nav_next_style_tabs'
		);

        $this->start_controls_tab(
			'wpt_tsm_slider_nav_next_style_normal_tab',
			[
				'label' => esc_html__( 'Normal', 'wpt-addon' ),
			]
		);

        // Icon Color
        $this->add_control(
			'wpt_tsm_slider_nav_next_icon_color',
			[
				'label' => esc_html__( 'Icon Color', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .wpt-tsm-carousel .owl-nav button.owl-next i' => 'color: {{VALUE}}',
				],
			]
		);

        // Icon Background
        $this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'wpt_tsm_slider_nav_next_icon_background',
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .wpt-tsm-carousel .owl-nav button.owl-next',
			]
		);

        $this->end_controls_tab();

        $this->start_controls_tab(
			'wpt_tsm_slider_nav_next_style_hover_tab',
			[
				'label' => esc_html__( 'Hover', 'wpt-addon' ),
			]
		);

        // Icon Color
        $this->add_control(
			'wpt_tsm_slider_nav_next_icon_hov_color',
			[
				'label' => esc_html__( 'Icon Color', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .wpt-tsm-carousel .owl-nav button.owl-next:hover i' => 'color: {{VALUE}}',
				],
			]
		);

        // Icon Background
        $this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'wpt_tsm_slider_nav_next_icon_hov_background',
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .wpt-tsm-carousel .owl-nav button.owl-next:hover',
			]
		);

        $this->end_controls_tab();
        $this->end_controls_tabs();

        // Icon Size
        $this->add_control(
			'wpt_tsm_slider_nav_icon_size_sty',
			[
				'label' => esc_html__( 'Icon Size', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

        // Font Size
        $this->add_responsive_control(
			'wpt_tsm_slider_nav_icon_size',
			[
				'label' => esc_html__( 'Icon Size', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 20,
				],
				'selectors' => [
					'{{WRAPPER}} .wpt-tsm-carousel .owl-nav button i' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);

        // Icon Width
        $this->add_control(
			'wpt_tsm_slider_nav_icon_width_sty',
			[
				'label' => esc_html__( 'Icon Width', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

        // Width
        $this->add_responsive_control(
			'wpt_tsm_slider_nav_icon_width',
			[
				'label' => esc_html__( 'Width', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 50,
				],
				'selectors' => [
					'{{WRAPPER}} .wpt-tsm-carousel .owl-nav button' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

        // Icon Height
        $this->add_control(
			'wpt_tsm_slider_nav_icon_height_sty',
			[
				'label' => esc_html__( 'Icon Height', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

        // Height
        $this->add_responsive_control(
			'wpt_tsm_slider_nav_icon_height',
			[
				'label' => esc_html__( 'Height', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 50,
				],
				'selectors' => [
					'{{WRAPPER}} .wpt-tsm-carousel .owl-nav button' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

        // Border Radius
        $this->add_control(
			'wpt_tsm_slider_nav_icon_border-radius',
			[
				'label' => esc_html__( 'Border Radius', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .wpt-tsm-carousel .owl-nav button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
                'default' => [
                    'unit' => '%',
                    'top' => '50',
                    'right' => '50',
                    'bottom' => '50',
                    'left' => '50',
                ]
			]
		);

        // Space Between
        $this->add_control(
			'wpt_tsm_slider_nav_icon_space',
			[
				'label' => esc_html__( 'Space Between', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

        // Space
        $this->add_responsive_control(
			'wpt_tsm_slider_nav_icon_between',
			[
				'label' => esc_html__( 'Margin', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 15,
				],
				'selectors' => [
					'{{WRAPPER}} .wpt-tsm-carousel .owl-nav button.owl-prev' => 'margin-right: {{SIZE}}{{UNIT}};',
				],
			]
		);

		// Horizontal Align
		$this->add_responsive_control(
			'wpt_tsm_slider_nav_icon_left',
			[
				'label' => esc_html__( 'Horizontal Align', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 0,
				],
				'selectors' => [
					'{{WRAPPER}} .wpt-tsm-carousel .owl-nav' => 'right: {{SIZE}}{{UNIT}};',
				],
			]
		);

		// Vertical Align
		$this->add_responsive_control(
			'wpt_tsm_slider_nav_icon_bottom',
			[
				'label' => esc_html__( 'Vertical Align', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 0,
				],
				'selectors' => [
					'{{WRAPPER}} .wpt-tsm-carousel .owl-nav' => 'top: {{SIZE}}{{UNIT}};',
				],
			]
		);

        $this->end_controls_section();
	}

    protected function render() {
        $settings = $this->get_settings_for_display();
        $this->add_render_attribute(
            'wpt_tsm_slider_options',
            [
                'id'          => 'wpt-tsm-slider-' . $this->get_id(),
                'data-loop'   => $settings[ 'wpt_tsm_slider_loop' ],
                'data-autoplay'   => $settings[ 'wpt_tsm_slider_autoplay' ],
                'data-pause'   => $settings[ 'wpt_tsm_slider_pause' ],
                'data-dots'   => $settings[ 'wpt_tsm_slider_dots' ],
                'data-navs'   => $settings[ 'wpt_tsm_slider_navs' ],
                'data-margin' => $settings[ 'wpt_tsm_slider_margin' ],
            ]
        );
        ?>
            <div class="wpt-testimonial-wrap">
                <div class="owl-carousel owl-theme wpt-tsm-carousel" <?php echo $this->get_render_attribute_string( 'wpt_tsm_slider_options' ); ?>>
                    <?php
                        if( $settings[ 'wpt_tsm_slider_list' ] ){
                            foreach( $settings[ 'wpt_tsm_slider_list' ] as $wpttsmitem ){
                                ?>
                                    <div class="item">
                                        <div class="wpt-tsm-wrap">
                                            <div class="wpt-tsm-avater">
                                                <img src="<?php echo esc_url( $wpttsmitem[ 'wpt_tsm_slider_image' ][ 'url' ] ); ?>" alt="<?php echo $wpttsmitem[ 'wpt_tsm_slider_list_client' ]; ?>">
                                            </div>
                                            <div class="wpt-tsm-content">
												<?php echo $wpttsmitem[ 'wpt_tsm_slider_list_content' ]; ?>
                                                <h3 class="wpt-tsm-client">
                                                    <?php echo $wpttsmitem[ 'wpt_tsm_slider_list_client' ]; ?>
                                                </h3>
                                                <h4 class="wpt-tsm-title">
                                                    <?php echo $wpttsmitem[ 'wpt_tsm_slider_list_title' ]; ?>
                                                </h4>
                                            </div>
                                        </div>
                                    </div>
                                <?php
                            }
                        }
                    ?>
                </div>
            </div>
        <?php
    }

    protected function _content_template() {
		?>
            <#
                view.addRenderAttribute(
                    'wpt_tsm_slider_options',
                    {
                        'id': 'wpt-tsm-slider-id',
                        'data-loop': settings.wpt_tsm_slider_loop,
                        'data-autoplay': settings.wpt_tsm_slider_autoplay,
                        'data-pause': settings.wpt_tsm_slider_pause,
                        'data-dots': settings.wpt_tsm_slider_dots,
                        'data-navs': settings.wpt_tsm_slider_navs,
                        'data-margin': settings.wpt_tsm_slider_margin
                    }
                );
            #>
            <div class="wpt-testimonial-wrap">
                <div class="owl-carousel owl-theme wpt-tsm-carousel" {{{ view.getRenderAttributeString( 'wpt_tsm_slider_options' ) }}} >
                <# if ( settings.wpt_tsm_slider_list.length ) { #>
                    <# _.each( settings.wpt_tsm_slider_list, function( wpttsmitem ) { #>
                        <div class="item">
                            <div class="wpt-tsm-wrap">
                                <div class="wpt-tsm-avater">
                                    <img src="{{ wpttsmitem.wpt_tsm_slider_image.url }}" alt="{{{ wpttsmitem.wpt_tsm_slider_list_client }}}">
                                </div>
                                <div class="wpt-tsm-content">
									{{{ wpttsmitem.wpt_tsm_slider_list_content }}}
                                    <h3 class="wpt-tsm-client">
                                        {{{ wpttsmitem.wpt_tsm_slider_list_client }}}
                                    </h3>
                                    <h4 class="wpt-tsm-title">
                                        {{{ wpttsmitem.wpt_tsm_slider_list_title }}}
                                    </h4>
                                </div>
                            </div>
                        </div>
                    <# }); #>
                <# } #>
                </div>
            </div>
        <?php
    }

}
Plugin::instance()->widgets_manager->register_widget_type( new Wpt_Testimonial_Slider() );