;( function( $ ){
    "use strict";

    //Wpt Services Carousel
    var serviceCarousel = function($scope, $){
        var $_this = $scope.find( '.wpt-service-carousel' );
        var $currentID = '#'+$_this.attr( 'id' ),
            $loop   = $_this.data( 'loop' ),
            $dots   = $_this.data( 'dots' ),
            $navs   = $_this.data( 'navs' ),
            $margin = $_this.data( 'margin' );
        var prevIcon = '<i class="fa-solid fa-arrow-left"></i>';
        var nextIcon = '<i class="fa-solid fa-arrow-right"></i>';

        var owl = $( $currentID );
        owl.owlCarousel({
            loop: $loop,
            margin: $margin,
            nav: $navs,
            dots: $dots,
            navText: [
                prevIcon,
                nextIcon,
            ],
            responsive:{
                0:{
                    items:1
                },
                600:{
                    items:3
                },
                1000:{
                    items:3
                }
            }
        });
    }

    var tsmCarousel = function( $scope, $ ){
        var $_this = $scope.find( '.wpt-tsm-carousel' );
        var $currentID = '#'+$_this.attr( 'id' ),
            $loop   = $_this.data( 'loop' ),
            $autoplay   = $_this.data( 'autoplay' ),
            $pause   = $_this.data( 'pause' ),
            $dots   = $_this.data( 'dots' ),
            $navs   = $_this.data( 'navs' ),
            $margin = $_this.data( 'margin' );
        var prevIcon = '<i class="fa-solid fa-arrow-left"></i>';
        var nextIcon = '<i class="fa-solid fa-arrow-right"></i>';

        var owl = $( $currentID );
        owl.owlCarousel({
            loop: $loop,
            autoplay: $autoplay,
            autoplayHoverPause: $pause,
            margin: $margin,
            nav: $navs,
            dots: $dots,
            navText: [
                prevIcon,
                nextIcon,
            ],
            responsive:{
                0:{
                    items:1
                },
                600:{
                    items:1
                },
                1000:{
                    items:1
                }
            }
        });
    }

    $(window).on('elementor/frontend/init', function () {
        elementorFrontend.hooks.addAction('frontend/element_ready/wpt-services-slider-id.default', serviceCarousel);
    });

    $(window).on('elementor/frontend/init', function () {
        elementorFrontend.hooks.addAction('frontend/element_ready/wpt-testimonial-slider-id.default', tsmCarousel);
    });

} )( jQuery );