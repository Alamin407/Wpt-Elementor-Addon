<?php
/**
 * Plugin Name: Wpt Addon
 * Plugin URI: https://w-prothemes.com
 * Description: W-Pro Themes addon for elementor. This plugin develop by MD AL AMIN ISLAM. You can add extra functionality using this plugin.
 * Version: 1.0.1
 * Author: Md. Al-Amin Islam
 * Author URI: https://w-prothemes.com
 * Text Domain: wpt-addon
 */
if( ! defined( 'ABSPATH' ) ) exit();

 /**
 * Elementor Extension main CLass
 * @since 1.0.0
 */
final class Wpt_Addon {

    // Plugin version
    const VERSION = '1.0.0';

    // Minimum Elementor Version
    const MINIMUM_ELEMENTOR_VERSION = '2.0.0';

    // Minimum PHP Version
    const MINIMUM_PHP_VERSION = '7.0';

    // Instance
    private static $_instance = null;

    /**
    * SIngletone Instance Method
    * @since 1.0.0
    */
    public static function instance() {
        if( is_null( self::$_instance ) ) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }

    /**
    * Construct Method
    * @since 1.0.0
    */
    public function __construct() {
        // Call Constants Method
        $this->define_constants();
        add_action( 'wp_enqueue_scripts', [ $this, 'scripts_styles' ] );
        add_action( 'init', [ $this, 'i18n' ] );
        add_action( 'plugins_loaded', [ $this, 'init' ] );
    }

    /**
    * Define Plugin Constants
    * @since 1.0.0
    */
    public function define_constants() {
        define( 'WPT_PLUGIN_URL', trailingslashit( plugins_url( '/', __FILE__ ) ) );
        define( 'WPT_PLUGIN_PATH', trailingslashit( plugin_dir_path( __FILE__ ) ) );
    }

    /**
    * Load Scripts & Styles
    * @since 1.0.0
    */
    public function scripts_styles() {
        // Register Styles
        wp_register_style( 'wpt-fontawesome', WPT_PLUGIN_URL . 'assets/dist/css/all.min.css', [], rand(), 'all' );
        wp_register_style( 'wpt-bootsrap', WPT_PLUGIN_URL . 'assets/dist/css/bootstrap.min.css', [], rand(), 'all' );
        wp_register_style( 'animate-css', WPT_PLUGIN_URL . 'assets/dist/css/animate.min.css', [], rand(), 'all' );
        wp_register_style( 'wpt-owl-carousel-css', WPT_PLUGIN_URL . 'assets/dist/css/owl.carousel.min.css', [], rand(), 'all' );
        wp_register_style( 'wpt-owl-carousel-theme', WPT_PLUGIN_URL . 'assets/dist/css/owl.theme.default.min.css', [], rand(), 'all' );
        wp_register_style( 'wpt-style', WPT_PLUGIN_URL . 'assets/dist/css/public.min.css', [], rand(), 'all' );

        //Register Scripts
        wp_register_script( 'wpt-bootstrap-js', WPT_PLUGIN_URL . 'assets/dist/js/bootstrap.min.js', [ 'jquery' ], rand(), true );
        wp_register_script( 'wow-js', WPT_PLUGIN_URL . 'assets/dist/js/wow.min.js', [ 'wpt-bootstrap-js' ], rand(), true );
        wp_register_script( 'paroller-js', WPT_PLUGIN_URL . 'assets/dist/js/jquery.paroller.min.js', [ 'wow-js' ], rand(), true );
        wp_register_script( 'wpt-owl-carousel-js', WPT_PLUGIN_URL . 'assets/dist/js/owl.carousel.min.js', [ 'paroller-js' ], rand(), true );
        wp_register_script( 'wpt-main-js', WPT_PLUGIN_URL . 'assets/dist/js/public.min.js', [ 'wpt-owl-carousel-js' ], rand(), true );

        //Enqueue Styles
        wp_enqueue_style( 'wpt-fontawesome' );
        wp_enqueue_style( 'wpt-bootsrap' );
        wp_enqueue_style( 'animate-css' );
        wp_enqueue_style( 'wpt-owl-carousel-css' );
        wp_enqueue_style( 'wpt-owl-carousel-theme' );
        wp_enqueue_style( 'wpt-style' );

        //Enqueue Scripts
        wp_enqueue_script( 'wpt-bootstrap-js' );
        wp_enqueue_script( 'wow-js' );
        wp_enqueue_script( 'paroller-js' );
        wp_enqueue_script( 'wpt-owl-carousel-js' );
        wp_enqueue_script( 'wpt-main-js' );
    }

    /**
    * Load Text Domain
    * @since 1.0.0
    */
    public function i18n() {
       load_plugin_textdomain( 'wpt-addon', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
    }

    /**
    * Initialize the plugin
    * @since 1.0.0
    */
    public function init() {
        // Check if the ELementor installed and activated
        if( ! did_action( 'elementor/loaded' ) ) {
            add_action( 'admin_notices', [ $this, 'admin_notice_missing_main_plugin' ] );
            return;
        }
        // Check if the ELementor installed and activated
        if( ! version_compare( ELEMENTOR_VERSION, self::MINIMUM_ELEMENTOR_VERSION, '>=' ) ) {
            add_action( 'admin_notices', [ $this, 'admin_notice_minimum_elementor_version' ] );
            return;
        }

        if( ! version_compare( PHP_VERSION, self::MINIMUM_PHP_VERSION, '>=' ) ) {
            add_action( 'admin_notices', [ $this, 'admin_notice_minimum_php_version' ] );
            return;
        }

        add_action( 'elementor/init', [ $this, 'init_category' ] );
        add_action( 'elementor/widgets/widgets_registered', [ $this, 'init_widgets' ] );
    }

    /**
    * Init Widgets
    * @since 1.0.0
    */
    public function init_widgets() {
        require_once WPT_PLUGIN_PATH . '/widgets/wpt-services-slider.php';
        require_once WPT_PLUGIN_PATH . '/widgets/wpt-testimonial-slider.php';
    }

    /**
    * Init Category Section
    * @since 1.0.0
    */
    public function init_category() {
        Elementor\Plugin::instance()->elements_manager->add_category(
            'wpt-for-elementor',
            [
                'title' => 'Wpt Addon'
            ],
            1
        );
    }

    /**
    * Admin Notice
    * Warning when the site doesn't have Elementor installed or activated
    * @since 1.0.0
    */
    public function admin_notice_missing_main_plugin() {
        if( isset( $_GET[ 'activate' ] ) ) unset( $_GET[ 'activate' ] );
        $message = sprintf(
            esc_html__( '"%1$s" requires "%2$s" to be installed and activated', 'wpt-addon' ),
            '<strong>'.esc_html__( 'WPT Addon', 'wpt-addon' ).'</strong>',
            '<strong>'.esc_html__( 'Elementor', 'wpt-addon' ).'</strong>'
        );

        printf( '<div class="notice notice-warning is-dimissible"><p>%1$s</p></div>', $message );
    }

    /**
    * Admin Notice
    * Warning when the site doesn't have a minimum required Elementor version.
    * @since 1.0.0
    */
    public function admin_notice_minimum_elementor_version() {
        if( isset( $_GET[ 'activate' ] ) ) unset( $_GET[ 'activate' ] );
        $message = sprintf(
            esc_html__( '"%1$s" requires "%2$s" version %3$s or greater', 'wpt-addon' ),
            '<strong>'.esc_html__( 'WPT Addon', 'wpt-addon' ).'</strong>',
            '<strong>'.esc_html__( 'Elementor', 'wpt-addon' ).'</strong>',
            self::MINIMUM_ELEMENTOR_VERSION
        );

        printf( '<div class="notice notice-warning is-dimissible"><p>%1$s</p></div>', $message );
    }

    /**
    * Admin Notice
    * Warning when the site doesn't have a minimum required PHP version.
    * @since 1.0.0
    */
    public function admin_notice_minimum_php_version() {
        if( isset( $_GET[ 'activate' ] ) ) unset( $_GET[ 'activate' ] );
        $message = sprintf(
            esc_html__( '"%1$s" requires "%2$s" version %3$s or greater', 'wpt-addon' ),
            '<strong>'. esc_html__( 'WPT Addon', 'wpt-addon' ).'</strong>',
            '<strong>'. esc_html__( 'PHP', 'wpt-addon' ).'</strong>',
            self::MINIMUM_PHP_VERSION
        );

        printf( '<div class="notice notice-warning is-dimissible"><p>%1$s</p></div>', $message );
    }

}

\Wpt_Addon::instance();
 